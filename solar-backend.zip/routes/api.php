<?php

use App\Http\Controllers\CotizacionesController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Contratos;
use App\Http\Controllers\ClientesController;
use App\Http\Controllers\ProductosController;
use App\Http\Controllers\ComprasController;
use App\Http\Controllers\UsuariosController;
use App\Http\Controllers\ProveedoresController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('register', [AuthController::class, 'register']);
Route::post('login', [AuthController::class, 'login']);
Route::post('login', [AuthController::class, 'login']);

Route::group(['middleware' => 'auth:api'], function () {
    Route::get('me', [AuthController::class, 'me']);
    Route::post('logout', [AuthController::class, 'logout']);
});

//contratos
Route::get('/getContratos', [Contratos::class, 'getContratos']);
Route::post('/getContratoById', [Contratos::class, 'getContratoById']);
Route::post('/addContrato', [Contratos::class, 'addContrato']);
Route::post('/editContrato', [Contratos::class, 'editContrato']);

//clientes
Route::get('/getClientes', [ClientesController::class, 'getClientes']);
Route::get('/obtenerClientes', [ClientesController::class, 'obtenerClientes']);
Route::post('/updateCliente', [ClientesController::class, 'updateCliente']);
Route::get('/deleteCliente', [ClientesController::class, 'deleteCliente']);


//productos
Route::post('/addProducto', [ProductosController::class, 'addProducto']);
Route::get('/getProductos', [ProductosController::class, 'getProductos']);
Route::post('/updateProducto', [ProductosController::class, 'updateProducto']);
Route::post('/deleteProducto', [ProductosController::class, 'deleteProducto']);

//proveedores
Route::get('/getProvedores', [ProveedoresController::class, 'getProvedores']);
Route::post('/addProveedor', [ProveedoresController::class, 'addProveedor']);
Route::post('/updateProvedores', [ProveedoresController::class, 'updateProvedores']);
Route::post('/deleteProveedor', [ProveedoresController::class, 'deleteProveedor']);

//cotizaciones
Route::get('/getCotizaciones', [CotizacionesController::class, 'getCotizaciones']);

//compras
Route::get('/getCompras', [ComprasController::class, 'getCompras']);

//usuarios
Route::get('/getUsuarios', [UsuariosController::class, 'getUsuarios']);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
